

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Servlet implementation class Estadistica
 */
@WebServlet("/Estadistica")
public class Estadistica extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Estadistica() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		out.print("<html><body>");
		out.print("<h1>" + "-- Abono para 2 dias --" + "<h1>");
		out.print("<p>" + "Entradas vendidas: " + request.getServletContext().getAttribute("Entradas vendidas abono 2") + "<p>");
		out.print("<p>" + "Entradas restantes: " + request.getServletContext().getAttribute("Contador abonos 2 dias") + "<p>");
		out.print("<h1>" + "-- Abono para 3 dias --" + "<h1>");
		out.print("<p>" + "Entradas vendidas: " + request.getServletContext().getAttribute("Entradas vendidas abono 3") + "<p>");
		out.print("<p>" + "Entradas restantes: " + request.getServletContext().getAttribute("Contador abonos 3 dias") + "<p>");
		out.print("<a href='/TTPS2024_ENTREGABLE1_Dellarupe/comprar.html'> Ir a comprar </a>");
		out.print("<html><body>");
		
		out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
