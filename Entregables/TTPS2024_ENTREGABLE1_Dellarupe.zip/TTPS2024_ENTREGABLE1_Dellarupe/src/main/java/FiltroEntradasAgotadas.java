

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpFilter;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

/**
 * Servlet Filter implementation class FiltroEntradasAgotadas
 */
public class FiltroEntradasAgotadas extends HttpFilter implements Filter {
	
	private FilterConfig config;
       
    /**
     * @see HttpFilter#HttpFilter()
     */
    public FiltroEntradasAgotadas() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		// place your code here
		String tipoAbono = request.getParameter("tipoAbono");
		
		HttpServletResponse resp = (HttpServletResponse) response;
		
		if (!this.hayEntradasAbono2(request) && !this.hayEntradasAbono3(request)) {
			resp.sendRedirect("/TTPS2024_ENTREGABLE1_Dellarupe/agotadas.html");
			return;
		}
		
		if (("dos".equals(tipoAbono) && !this.hayEntradasAbono2(request)) || ("tres".equals(tipoAbono) && !this.hayEntradasAbono3(request))) {
			resp.sendRedirect("/TTPS2024_ENTREGABLE1_Dellarupe/abonoAgotado.html");
			return;
		}
		
		// pass the request along the filter chain
		chain.doFilter(request, response);
	}
	
	private boolean hayEntradasAbono2(ServletRequest r) {
		int cantAbonos2 = (int) r.getServletContext().getAttribute("Contador abonos 2 dias");
		return (cantAbonos2 > 0);
	}
	
	private boolean hayEntradasAbono3(ServletRequest r) {
		int cantAbonos3 = (int) r.getServletContext().getAttribute("Contador abonos 3 dias");
		return (cantAbonos3 > 0);
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
