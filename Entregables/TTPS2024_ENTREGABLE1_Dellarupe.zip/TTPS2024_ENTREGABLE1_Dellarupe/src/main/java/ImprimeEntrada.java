import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.util.concurrent.ThreadLocalRandom;

import javax.imageio.ImageIO;
/**
 * Servlet implementation class ImprimeEntrada
 */
@WebServlet("/ImprimeEntrada")
public class ImprimeEntrada extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ImprimeEntrada() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//PrintWriter out = response.getWriter().append("Served at: ").append(request.getContextPath());	

        // Parámetros de la solicitud
        String nombres = request.getParameter("Nombres");
        String apellido = request.getParameter("Apellido");
        String dni = request.getParameter("DNI");
        String tipoAbono = request.getParameter("tipoAbono");
        
        // Actualiza parametros de contexto
        if ("dos".equals(tipoAbono)) {
			int cantAbonos2 = (int) this.getServletContext().getAttribute("Contador abonos 2 dias");
			cantAbonos2--;
			this.getServletContext().setAttribute("Contador abonos 2 dias", cantAbonos2);
			int vendidas2 = (int) this.getServletContext().getAttribute("Entradas vendidas abono 2");
			vendidas2++;
			this.getServletContext().setAttribute("Entradas vendidas abono 2", vendidas2);
		} else {
			int cantAbonos3 = (int) this.getServletContext().getAttribute("Contador abonos 3 dias");
			cantAbonos3--;
			this.getServletContext().setAttribute("Contador abonos 3 dias", cantAbonos3);
			int vendidas3 = (int) this.getServletContext().getAttribute("Entradas vendidas abono 3");
			vendidas3++;
			this.getServletContext().setAttribute("Entradas vendidas abono 3", vendidas3);
		}

        // Contenido del código QR
        String textoQR = ("Entrada para: " + nombres + " " + apellido + " " + dni);
        if (((int)(Math.random() * 100)) % 2 == 0) {
            textoQR = textoQR + "\n" + "¡¡Felicitaciones!! Te ganaste una remera." + "\n" +
                      "El dia del evento pasa por el stand TTPS y retirala con el QR";
        } else {
            textoQR = textoQR + "\n" + "No te ganaste una remera, pero esperamos que disfrutes mucho el show!";
        }

        // Crear código QR
        int qrWidth = 270;
        int qrHeight = 270;
        QRCodeWriter qrCodeWriter = new QRCodeWriter();
        BitMatrix bitMatrix;
        
        try {
            bitMatrix = qrCodeWriter.encode(textoQR, BarcodeFormat.QR_CODE, qrWidth, qrHeight);
        } catch (WriterException e) {
            throw new ServletException("Error al generar el código QR", e);
        }

        // Convertir BitMatrix a BufferedImage (QR)
        BufferedImage qrImage = MatrixToImageWriter.toBufferedImage(bitMatrix);

        // Cargar la imagen de fondo
        BufferedImage backgroundImage = ImageIO.read(this.getServletContext().getResourceAsStream("/WEB-INF/quilmes-rock-2025.jpg"));

        // Crear una nueva imagen combinada
        int combinedWidth = backgroundImage.getWidth();
        int combinedHeight = backgroundImage.getHeight();
        BufferedImage combinedImage = new BufferedImage(combinedWidth, combinedHeight, BufferedImage.TYPE_INT_RGB);

        // Dibujar la imagen de fondo y el código QR sobre la imagen combinada
        Graphics2D g = combinedImage.createGraphics();

        // Dibujar imagen de fondo
        g.drawImage(backgroundImage, 0, 0, null);

        // Dibujar el código QR en la esquina inferior derecha o donde lo prefieras
        int qrX = combinedWidth - qrWidth - 10;  // Ajusta las coordenadas si es necesario
        int qrY = combinedHeight - qrHeight - 10;
        g.drawImage(qrImage, qrX, qrY, null);

        // Finalizar gráficos
        g.dispose();

        // Enviar la imagen combinada como respuesta
        try (OutputStream outStream = response.getOutputStream()) {
            ImageIO.write(combinedImage, "jpg", outStream);
        }
       
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
