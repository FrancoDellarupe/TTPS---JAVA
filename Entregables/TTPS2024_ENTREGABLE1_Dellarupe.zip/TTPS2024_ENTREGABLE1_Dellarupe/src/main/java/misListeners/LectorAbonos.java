package misListeners;

import jakarta.servlet.AsyncEvent;
import jakarta.servlet.AsyncListener;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletContextAttributeEvent;
import jakarta.servlet.ServletContextAttributeListener;
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.ServletRequestAttributeEvent;
import jakarta.servlet.ServletRequestAttributeListener;
import jakarta.servlet.ServletRequestEvent;
import jakarta.servlet.ServletRequestListener;
import jakarta.servlet.annotation.WebListener;
import jakarta.servlet.http.HttpSessionActivationListener;
import jakarta.servlet.http.HttpSessionAttributeListener;
import jakarta.servlet.http.HttpSessionBindingEvent;
import jakarta.servlet.http.HttpSessionBindingListener;
import jakarta.servlet.http.HttpSessionEvent;
import jakarta.servlet.http.HttpSessionIdListener;
import jakarta.servlet.http.HttpSessionListener;

/**
 * Application Lifecycle Listener implementation class LectorAbonos
 *
 */
public class LectorAbonos implements ServletContextListener {

	/**
     * @see ServletContextListener#contextInitialized(ServletContextEvent)
     */
    public void contextInitialized(ServletContextEvent sce)  { 
    	ServletContext contexto = sce.getServletContext();
    	
    	Integer a2 = Integer.parseInt(sce.getServletContext().getInitParameter("Abonos 2 dias"));
    	Integer a3 = Integer.parseInt(sce.getServletContext().getInitParameter("Abonos 3 dias"));
    	
    	Integer ini = 0;
    
    	contexto.setAttribute("Contador abonos 2 dias", a2);
    	contexto.setAttribute("Contador abonos 3 dias", a3);
    	contexto.setAttribute("Entradas vendidas abono 2", ini);
    	contexto.setAttribute("Entradas vendidas abono 3", ini);
    }

	/**
     * @see ServletContextListener#contextDestroyed(ServletContextEvent)
     */
    public void contextDestroyed(ServletContextEvent sce)  { 
         // TODO Auto-generated method stub
    }
	
}
